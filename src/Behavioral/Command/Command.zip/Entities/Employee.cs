﻿namespace Command.Entities
{
    public class Employee
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public Employee(int ıd, string name)
        {
            Id = ıd;
            Name = name;
        }
    }
}
